﻿using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TeamProject
{
    public partial class Form1 : Form
    {
        ArrayList eList;
        Event selectedEvent;
        //Users attendees;
        ArrayList totalUsers;
        ArrayList people;

        public Form1()
        {
            InitializeComponent();
            
           
            DateTime thisDay = DateTime.Today;
            String dateString = thisDay.ToString("yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);
            eList = Event.getEventList(dateString);

        }

        

        private void button4_Click(object sender, EventArgs e)
        {
            button4.BackColor = Color.Red;
            panel2.Visible = true;
            button5.Enabled = false;
            totalUsers = Users.getUsers();
            for (int i = 0; i < totalUsers.Count; i++)
            {
                listBox1.Items.Add(totalUsers[i]);
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
         
            if(comboBox1.SelectedItem == null)
            {
                String message = "Please select a time.";
                String caption = "Time required.";
                MessageBoxButtons button1 = MessageBoxButtons.OK;
                MessageBoxIcon icon1 = MessageBoxIcon.Warning;
                MessageBox.Show(message, caption, button1, icon1);
            }
            else
            {
                button1.BackColor = Color.Red;
                button2.Visible = true;
                panel1.Visible = true;
                people = new ArrayList();

                foreach (object p in listBox1.SelectedItems)
                {
                    people.Add(p.ToString());
                }
                listBox1.Items.Clear();
                findAvail(people);
            }
                



        }
        //determines if times are valid, adds the event, and the users involved
        private void button2_Click(object sender, EventArgs e)
        {
            String start;
            if(listBox1.SelectedItem.ToString().Substring(1,1).Equals(":"))
            {
                start = listBox1.SelectedItem.ToString().Substring(0, 4);
            }
            else
            {
                start = listBox1.SelectedItem.ToString().Substring(0, 5);
            }
            String end;
            if (listBox1.SelectedItem.ToString().Substring(5, 1).Equals("-"))
            {
                end = listBox1.SelectedItem.ToString().Substring(7);
            }
            else
            {
                end = listBox1.SelectedItem.ToString().Substring(8);
            }

            if(textBox5.Text.Substring(1,1).Equals(":")) //if user doesn't enter time in 00:00 format
            {
                textBox5.Text = "0" + textBox5.Text;
            }
            if (textBox6.Text.Substring(1, 1).Equals(":"))
            {
                textBox6.Text = "0" + textBox6.Text;
            }

            if (start.CompareTo(textBox5.Text)>0 || start.CompareTo(textBox6.Text) >= 0 || end.CompareTo(textBox5.Text)<=0 || end.CompareTo(textBox6.Text)<0)
            {
                //Warning message for wrong time
                string caption = "Error";
                string message = "The chosen time frame overlaps with other time frames.";
                MessageBoxButtons button = MessageBoxButtons.OK;
                MessageBoxIcon icon = MessageBoxIcon.Warning;
                MessageBox.Show(message, caption, button, icon);

                
            }
            else
            {
                Event newEvent = new Event();
                newEvent.updateEventValue(textBox3.Text, textBox5.Text, textBox6.Text, textBox7.Text, textBox4.Text, monthCalendar1.SelectionRange.Start.ToString("yyyy-MM-dd"), textBox8.Text);
                bool noConflict = newEvent.checkConflict(eList);
                if (noConflict)
                {
                    string caption = "Event Added.";
                    string message = "The event has been added.";
                    MessageBoxButtons button = MessageBoxButtons.OK;
                    MessageBoxIcon icon = MessageBoxIcon.Information;
                     MessageBox.Show(message, caption, button, icon);
                    //add event
                    newEvent.insertEvent();
                    //add everyone involved

                    String meet = ""; //finds the meeting room being used
                    for(int i = 0;i<listBox1.SelectedIndex;i++)
                    {
                        if(listBox1.Items[i].ToString().Substring(0,12).Equals("Meeting Room"))
                        {
                            meet = listBox1.Items[i].ToString();
                        }
                    }
                    people.Add(meet);
                foreach(object p in people)
                    {
                        string connStr = "server=csdatabase.eku.edu;user=stu_csc340;database=csc340_db;port=3306;password=Colonels18;";
                        MySqlConnection conn = new MySqlConnection(connStr);
                        try
                        {
                            Console.WriteLine("Connecting to MySQL...");
                            conn.Open();
                            string sql = "INSERT INTO michaelinvolve (userID, eventID) VALUES((SELECT userID FROM michaeluser WHERE michaeluser.name = @person),(SELECT eventID FROM michaelevent ORDER BY eventID DESC LIMIT 1)); ";
                            MySqlCommand cmd = new MySqlCommand(sql, conn);
                            cmd.Parameters.AddWithValue("@person", p);
                            //MySqlDataAdapter myAdapter = new MySqlDataAdapter(cmd);
                            cmd.ExecuteNonQuery();
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.ToString());
                        }
                        conn.Close();
                    }

                    textBox3.Text = "";
                    textBox4.Text = "";
                    textBox5.Text = "";
                    textBox6.Text = "";
                    textBox7.Text = "";
                    textBox8.Text = "";
                    listBox1.Items.Clear();
                    panel1.Visible = false;
                    panel2.Visible = false;
                    button5.Enabled = true;
                    button1.BackColor = SystemColors.ButtonFace;
                    button4.BackColor = SystemColors.ButtonFace;
                }
                else
                {
                    string caption1 = "Error.";
                    string message1 = "There was an error in adding the event.";
                    MessageBoxButtons button1 = MessageBoxButtons.OK;
                    MessageBoxIcon icon1 = MessageBoxIcon.Warning;
                    MessageBox.Show(message1, caption1, button1, icon1);
                }
            }
            

            
        }
        //takes user back to the beginning
        private void button3_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            panel2.Visible = false;
            panel3.Visible = false;
            button4.Enabled = true;
            button5.Enabled = true;
            button7.Enabled = true;
            button1.BackColor = SystemColors.ButtonFace;
            button4.BackColor = SystemColors.ButtonFace;
            button5.BackColor = SystemColors.ButtonFace;
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";
            listBox1.Items.Clear();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            panel3.Visible = true;
            panel1.Visible = true;
            panel2.Visible = false;
            button5.BackColor = Color.Red;
            button2.Visible = false;
            button3.Visible = true;
            button4.Enabled = false;
            
           
        }

        public void showAll()
        {
            monthCalendar1.Visible = true;
           // panel1.Visible = true;
           // panel2.Visible = true;
            button4.Visible = true;
            button5.Visible = true;
        }
        //used to login by checking their username and password.
        private void button6_Click(object sender, EventArgs e)
        {

            Users tempUser = new Users(textBox10.Text, textBox9.Text);
            if(tempUser.checkUserPass(tempUser.getUserName(),tempUser.getPassword()))
            {
                showAll();
             
                textBox9.Text = "";
                textBox10.Text = "";
                button7.Visible = true;
                panel4.Visible = false;
            }
            else
            {
                string caption1 = "Error.";
                string message1 = "The username and/or password is incorrect.";
                MessageBoxButtons button1 = MessageBoxButtons.OK;
                MessageBoxIcon icon1 = MessageBoxIcon.Warning;
                MessageBox.Show(message1, caption1, button1, icon1);
            }
            
        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
            String thisDate = monthCalendar1.SelectionRange.Start.ToString("yyyy-MM-dd");

            
            eList = Event.getEventList(thisDate);
           
            listBox2.Items.Clear();
            for (int i = 0; i < eList.Count; i++)
            {
                Event currentEvent = (Event)eList[i];
                String aString = currentEvent.getStartTime() + " " + currentEvent.getTitle();
                listBox2.Items.Add(aString);
            }
            if (eList.Count == 0)
                selectedEvent = null;
            else
                selectedEvent = (Event)eList[0];
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox2.SelectedIndex == -1)
                listBox2.SelectedIndex = 0;
            //panel1.Visible = true;
            Event currentEvent = (Event)eList[listBox2.SelectedIndex];
            selectedEvent = currentEvent;
            textBox3.Text = currentEvent.getTitle();
            textBox5.Text = currentEvent.getStartTime();
            //comboBox1.Visible = false;
            textBox5.Visible = true;
            textBox6.Text = currentEvent.getEndTime();
            
            //EndingTimeTextBox.Visible = true;
            textBox8.Text = currentEvent.getDescription();
            textBox7.Text = currentEvent.getReminder();
            textBox4.Text = currentEvent.getLocation();
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        //used to find available times in each meeting room
        public void findAvail(ArrayList p)
        {
            ArrayList rooms = new ArrayList();
            ArrayList times = new ArrayList();
            String thisDate = monthCalendar1.SelectionRange.Start.ToString("yyyy-MM-dd");

            DataTable myTable = new DataTable();
            string connStr = "server=csdatabase.eku.edu;user=stu_csc340;database=csc340_db;port=3306;password=Colonels18;";
            MySqlConnection conn = new MySqlConnection(connStr);
            try
            {
                Console.WriteLine("Connecting to MySQL...");
                conn.Open();
                string sql = "SELECT michaeluser.name FROM michaeluser WHERE michaeluser.name LIKE \"Meeting Room%\"; ";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                
                MySqlDataAdapter myAdapter = new MySqlDataAdapter(cmd);
                myAdapter.Fill(myTable);
                Console.WriteLine("Table is ready.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();

            foreach(DataRow row in myTable.Rows)
            {
                rooms.Add(row["name"].ToString());
            }

            for(int i = 0;i<rooms.Count;i++) //loop through all rooms to find available time
            {
                ArrayList people = new ArrayList(); //selected attendees
                people = p;
                times = new ArrayList();

                DataTable myTable1 = new DataTable();

                conn = new MySqlConnection(connStr);
                try
                {
                    Console.WriteLine("Connecting to MySQL...");
                    conn.Open();
                    string sql = "SELECT e.startTime, e.endTime FROM michaelEvent e JOIN michaelinvolve i ON i.eventID = e.eventID JOIN michaelUser u ON i.userID = u.userID WHERE (u.name = \"" + rooms[i] + "\"" +
                        " ";
                    Console.WriteLine(sql);
                   // Console.WriteLine("People ount part 2 = " + people.Count);
                    for(int j = 0; j<people.Count; j++)
                    {
                        sql += " OR u.name = \"" + people[j] + "\"";
                    }
                    Console.WriteLine("People count = " + people.Count);
                    sql += ") AND e.date = \"" + thisDate + "\" ORDER by e.startTime;"; //full sql statement
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    Console.WriteLine("Room = "+ rooms[i]);

                    MySqlDataAdapter myAdapter = new MySqlDataAdapter(cmd);
                    myAdapter.Fill(myTable1); //fills table with all start and end times
                    Console.WriteLine("Table is ready.");

                    Console.WriteLine("String = " + sql);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                conn.Close();

                //fill times array with start and end times
                times.Add("08:00");
                foreach(DataRow row in myTable1.Rows)
                {
                    times.Add(row["startTime"].ToString());
                    times.Add(row["endTime"].ToString());
                }
                times.Add("17:00");
                foreach(Object j in times)
                {
                    Console.WriteLine(j);
                    Console.WriteLine("Count " + times.Count);
                }
               


                // FIND GAPS
                int meetLen = 0;
                if(comboBox1.SelectedItem==null)
                {
                    //warning message
                    
                }
                else if(comboBox1.SelectedItem.Equals("105 minutes"))
                {
                    meetLen = 105;
                }
                else if(comboBox1.SelectedItem.Equals("120 minutes"))
                {
                    meetLen = 120;
                }
                else
                {
                    String num = comboBox1.SelectedItem.ToString();
                    num = num.Substring(0, 2);
                    meetLen = int.Parse(num);
                }

                listBox1.Items.Add(rooms[i]);

                for (int j = 0; j<times.Count-1; j+= 2)//check the inbetween
                {
                    String curr = (String)times[j];
                    String next = (String)times[j + 1];

                   
                    if (validGap(curr,next,meetLen))
                    {
                        //add gap
                        listBox1.Items.Add(curr + " - " + next);
                    }
                    
                }
    

            }

        }

        public bool validGap(String c, String n,int t)
        {
            bool answer = true;
            int hour1 = 0;
            int min1 = 0;
            int hour2 = 0;
            int min2 = 0;

            if(c.Substring(1,1).Equals(":")) //checks if times is less than 10:00
            {
                hour1 = int.Parse(c.Substring(0, 1));
                min1 = int.Parse(c.Substring(2, 2));
            }
            else
            {
                hour1 = int.Parse(c.Substring(0, 2));
                min1 = int.Parse(c.Substring(3, 2));
            }
            
            if(n.Substring(1,1).Equals(":"))
            {
                hour2 = int.Parse(n.Substring(0, 1));
                min2 = int.Parse(n.Substring(2, 2));
            }
            else
            {
                hour2 = int.Parse(n.Substring(0, 2));
                min2 = int.Parse(n.Substring(3, 2));
            }
            
            int diff = (hour2 * 60 + min2) - (hour1 * 60 + min1);

            if(t>diff)
            {
                answer = false;
            }
            return answer;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           // panel1.Visible = true;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string caption1 = "Log Out.";
            string message1 = "Are you sure you want to log out?";
            MessageBoxButtons button1 = MessageBoxButtons.YesNo;
            MessageBoxIcon icon1 = MessageBoxIcon.Question;
            DialogResult result;
            result = MessageBox.Show(message1, caption1, button1, icon1);

            
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                panel4.Visible = true;
                panel1.Visible = false;
                panel2.Visible = false;
                panel3.Visible = false;
                button4.Visible = false;
                button5.Visible = false;
                button7.Visible = false;
                monthCalendar1.Visible = false;
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }
    }
}
