﻿using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeamProject
{
    class Users
    {
        String name;
        String userName;
        String password;
        int userID;

        //ArrayList info;


        //Constructors
        public Users()
        {

        }
        public Users(String name1, String userName1, String password1)
        {
            name = name1;
            userName = userName1;
            password = password1;
        }
        public Users(String userName1, String password1)
        {
            userName = userName1;
            password = password1;
        }

        //getter methods
        public String getName()
        {
            return name;
        }
        public String getUserName()
        {
            return userName;
        }
        public String getPassword()
        {
            return password;
        }
        public int getUserID()
        {
            return userID;
        }

        //method for retrieving users in the database
        public static ArrayList getUsers()
        {
            ArrayList totalUsers = new ArrayList();
            DataTable myTable = new DataTable();

            string connStr = "server=csdatabase.eku.edu;user=stu_csc340;database=csc340_db;port=3306;password=Colonels18;";
            MySqlConnection conn = new MySqlConnection(connStr);
            try
            {
                Console.WriteLine("Connecting to MySQL...");
                conn.Open();
                string sql = "SELECT michaeluser.name FROM michaeluser where michaeluser.name NOT LIKE \"Meeting Room%\" ;";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                
                MySqlDataAdapter myAdapter = new MySqlDataAdapter(cmd);
                myAdapter.Fill(myTable);

                foreach (DataRow row in myTable.Rows)
                {
                    totalUsers.Add(row["name"]);
                }

                Console.WriteLine("Table is ready.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();

            return totalUsers;
        }

        //determines if entered user and password are correct
        public bool checkUserPass(String userName1, String password1)
        {
            DataTable myTable = new DataTable();
            Users thisUser = new Users();

            string connStr = "server=csdatabase.eku.edu;user=stu_csc340;database=csc340_db;port=3306;password=Colonels18;";
            MySqlConnection conn = new MySqlConnection(connStr);
            try
            {
                Console.WriteLine("Connecting to MySQL...");
                conn.Open();
                string sql = "SELECT * FROM michaeluser WHERE username=@myUserName ORDER BY username ASC;";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@myUserName",userName1);
                MySqlDataAdapter myAdapter = new MySqlDataAdapter(cmd);
                myAdapter.Fill(myTable);

                foreach (DataRow row in myTable.Rows)
                {
                    
                    thisUser.userID = (int)row["UserID"];
                    thisUser.name = row["name"].ToString();
                    thisUser.userName = row["username"].ToString();
                    thisUser.password = row["password"].ToString();
                }

                    Console.WriteLine("Table is ready.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();

            if ((thisUser.getUserName() != null && thisUser.getPassword() != null)&&(thisUser.getUserName().Equals(userName1) && thisUser.getPassword().Equals(password1)))
            {
                return true;
            }


            return false;
        }
    }
    
}
