﻿using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeamProject
{
    class Event
    {
        String title;
        String startTime;
        String endTime;
        String location;
        String reminder;
        String date;
        String description;
       // String empID = "1";
       // User[] attendees;
        int eventID;

        //constructors
        public Event()
        {

        }
        public Event(String t, String st, String et, String r, String l, String d, String des)
        {
            title = t;
            startTime = st;
            endTime = et;
            location = l;
            reminder = r;
            date = d;
            description = des;
        }
        public void updateEventValue(String t, String st, String et, String r, String l, String d, String des)
        {
            title = t;
            startTime = st;
            endTime = et;
            location = l;
            reminder = r;
            date = d;
            description = des;
        }
        //checks time conflicts
        public bool checkConflict(ArrayList eList)
        {
            if (eList.Count == 0)
                return true;
            for (int i = 0; i < eList.Count; i++)
            {
                Event thisEvent = (Event)eList[i];
                if (startTime.CompareTo(thisEvent.getEndTime()) >= 0 || endTime.CompareTo(thisEvent.getStartTime()) <= 0)
                    continue;
                else
                    return false;
            }
            return true;
        }

        //getter methods
        public String getStartTime()
        {
            return startTime;
        }
        public String getTitle()
        {
            return title;
        }
        public String getEndTime()
        {
            return endTime;
        }
        public String getReminder()
        {
            return reminder;
        }
        public String getLocation()
        {
            return location;
        }
        public String getDate()
        {
            return date;
        }
        public String getDescription()
        {
            return description;
        }
        public int getEventID()
        {
            return eventID;
        }

       
        //gets a list of events on a certain date
        public static System.Collections.ArrayList getEventList(string dateString)
        {
            ArrayList eventList = new ArrayList();  //a list to save the events
            //prepare an SQL query to retrieve all the events on the same, specified date
            DataTable myTable = new DataTable();
            string connStr = "server=csdatabase.eku.edu;user=stu_csc340;database=csc340_db;port=3306;password=Colonels18;";
            MySqlConnection conn = new MySqlConnection(connStr);
            try
            {
                Console.WriteLine("Connecting to MySQL...");
                conn.Open();
                string sql = "SELECT * FROM michaelevent WHERE date=@myDate ORDER BY startTime ASC";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@myDate", dateString);
                MySqlDataAdapter myAdapter = new MySqlDataAdapter(cmd);
                myAdapter.Fill(myTable);
                Console.WriteLine("Table is ready.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();
            //convert the retrieved data to events and save them to the list
            foreach (DataRow row in myTable.Rows)
            {
                Event newEvent = new Event();

                newEvent.title = row["title"].ToString();
                newEvent.date = row["date"].ToString();
                newEvent.startTime = row["startTime"].ToString();
                newEvent.endTime = row["endTime"].ToString();
                newEvent.description = row["description"].ToString();
                newEvent.location = row["location"].ToString();
                newEvent.eventID = (int)row["eventID"];
                newEvent.reminder = row["reminder"].ToString();
                eventList.Add(newEvent);
            }
            return eventList;  //return the event list
        }


        public void insertEvent()
        {
            string connStr = "server=csdatabase.eku.edu;user=stu_csc340;database=csc340_db;port=3306;password=Colonels18;";
            MySql.Data.MySqlClient.MySqlConnection conn = new MySql.Data.MySqlClient.MySqlConnection(connStr);
            try
            {
                Console.WriteLine("Connecting to MySQL...");
                conn.Open();
                string sql = "INSERT INTO michaelevent (title, date, startTime, endTime, reminder, location, description, userID) VALUES (@title, @date, @startTime, @endTime, @reminder, @location, @description, @empid);";
                MySql.Data.MySqlClient.MySqlCommand cmd = new MySql.Data.MySqlClient.MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@title", title);
                cmd.Parameters.AddWithValue("@date", date);
                cmd.Parameters.AddWithValue("@startTime", startTime);
                cmd.Parameters.AddWithValue("@endTime", endTime);
                cmd.Parameters.AddWithValue("@reminder", reminder);
                cmd.Parameters.AddWithValue("@description", description);
                cmd.Parameters.AddWithValue("@location", location);
                cmd.Parameters.AddWithValue("@empid", 1);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();
            Console.WriteLine("Done.");
        }
        
    }
}
